package exercice4;

import java.util.HashMap;
//CLasse Environnement qui contient l'ensemble de r�ference
public class Environment {

    static public HashMap<String, Reference> listRef;

    // constructor
    public Environment(){
        listRef = new HashMap<String, Reference>();
    }

    static public void addReference(String string, Reference spaceRef) {
        listRef.put(string, spaceRef);
    }

    static public Reference getReferenceByName(String receiverName) {
        return listRef.get(receiverName);
    }

}
