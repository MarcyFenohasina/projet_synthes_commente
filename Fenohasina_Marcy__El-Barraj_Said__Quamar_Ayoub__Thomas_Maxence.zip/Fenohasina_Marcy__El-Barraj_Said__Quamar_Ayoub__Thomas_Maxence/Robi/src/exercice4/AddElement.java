package exercice4;

import graphicLayer.GElement;
import graphicLayer.GSpace;
import stree.parser.SNode;
//Classe AddElement 
//Sa fonction est d'ajouter un element � partir de l'expression pass�e en param�tre

public class AddElement implements Command{
    public AddElement(){}

    @Override
    public Reference run(Reference ref, SNode methode) {
    	//Traitement des cas d'erreurs d'abord
        if(methode.get(2) == null || methode.get(2).contents() == null){
            System.out.println("Erreur AddElement : pas de param�tre");
        } else { 
            if (Environment.getReferenceByName(methode.get(2).contents()) == null){
                System.out.println("Erreur AddElement : Reference "+ methode.get(2).contents() +" non trouv�");
            } else {
                GElement g = ((GElement) (Environment.getReferenceByName(methode.get(2).contents())).receiver);
                if(g == null){
                    System.out.println("Erreur AddElement : element is null");
                } else{
                	//Ajout de l'�lement dans l'objet space
                    ((GSpace) ref.receiver).addElement(g);
                }
            }
        }
        return ref;
    }

}