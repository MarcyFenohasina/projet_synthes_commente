package exercice3;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import tools.Tools;

import graphicLayer.GRect;
import graphicLayer.GSpace;
import stree.parser.SNode;
import stree.parser.SParser;

public class Exercice3_0 {
	GSpace space = new GSpace("Exercice 3", new Dimension(200, 100));
	GRect robi = new GRect();
	String script = "" +
	"   (space setColor green) " +
	"   (robi setColor black)" +
	"   (space sleep 1000)" +
	"   (space setColor white)\n" + 
	"   (space sleep 1000)" +
	"	(robi setColor red) \n" + 
	"   (space sleep 1000)" +
	"	(robi translate 100 0)\n" + 
	"	(space sleep 1000)\n" + 
	"	(robi translate 0 50)\n" + 
	"	(space sleep 1000)\n" + 
	"	(robi translate -100 0)\n" + 
	"	(space sleep 1000)\n" + 
	"	(robi translate 0 -40)";

	public Exercice3_0() {
		space.addElement(robi);
		space.open();
		this.runScript();
	}

	private void runScript() {
		SParser<SNode> parser = new SParser<>();
		List<SNode> rootNodes = null;
		try {
			rootNodes = parser.parse(script);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Iterator<SNode> itor = rootNodes.iterator();
		while (itor.hasNext()) {
			this.run(itor.next());
		}
	}
	//Appel de getCommandFromExpr
	private void run(SNode expr) {
		Command cmd = getCommandFromExpr(expr);
		if (cmd == null)
			throw new Error("unable to get command for: " + expr);
		
		cmd.run();
		
	}
	//R�cup�ration de la commande � partir de expr (S-expression)
	Command getCommandFromExpr(SNode expr) {
		//V�rification des �lements du SNode cas par cas
		//cas space setColor
		if(expr.get(0).contents().equals("space")&& expr.get(1).contents().equals("setColor"))
		{
			Color c = Tools.getColorByName(expr.get(2).contents());
			SpaceChangeColor Scc = new SpaceChangeColor (c);
			return Scc;
		}
		//Cas robi setColor
		if(expr.get(0).contents().equals("robi")&& expr.get(1).contents().equals("setColor"))
		{
			Color c = Tools.getColorByName(expr.get(2).contents());
			RobiChangeColor Rcc = new RobiChangeColor (c);
			return 	Rcc;
		}
		//cas Space sleep
		if(expr.get(0).contents().equals("space")&& expr.get(1).contents().equals("sleep"))
		{
			int timesleep = Integer.parseInt(expr.get(2).contents());
			Slleep sllp = new Slleep(timesleep);
			return sllp;
		}
		//cas robi translate : creation d'un point et d�placement du robi 
		if(expr.get(0).contents().equals("robi")&& expr.get(1).contents().equals("translate"))
		{
			Point p = new Point();
			int x = Integer.parseInt(expr.get(2).contents()); 
			int y = Integer.parseInt(expr.get(3).contents());
			p.move(x, y);
			Translatexy Tsl = new Translatexy (p);
			return Tsl;
		}
		
		return null;
	}

	public static void main(String[] args) {
		new Exercice3_0();
	}

	public interface Command {
		abstract public void run();
	}
	public class Slleep implements Command{
		int secondes ; 
		public Slleep(int secondes_1) {
			this.secondes=secondes_1;
		}
		@Override
		public void run() {
			try {
				Thread.sleep(secondes);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public class RobiChangeColor implements Command {
		Color newColor;

		public RobiChangeColor(Color newColor) {
			this.newColor = newColor;
		}

		@Override
		public void run() {
			robi.setColor(newColor);
		}

	}
	public class Translatexy implements Command {
		Point x ;
		public Translatexy(Point x_1)
		{
			this.x = x_1;
		}
		@Override
		public void run() {
			robi.translate(x);
		}
		
	}
	public class SpaceChangeColor implements Command {
		Color newColor;

		public SpaceChangeColor(Color newColor) {
			this.newColor = newColor;
		}

		@Override
		public void run() {
			space.setColor(newColor);
		}

	}
}