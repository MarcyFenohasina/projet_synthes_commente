package exercice5.examples;

 /*
	(space setColor black)(robi setColor yellow)(space sleep 2000)
	(robi setColor yellow) 
	(space sleep 2000) 
	(space setColor white)  
	(space sleep 1000) 	
	(space add robi (GRect new))
	(robi setColor green)
	(robi translate 100 50)
	(space del robi)
	(robi setColor red)		  
	(space sleep 1000)
	(robi translate 100 0)
	(space sleep 1000)
	(robi translate 0 50)
	(space sleep 1000)
	(robi translate -100 0)
	(space sleep 1000)
	(robi translate 0 -40) ) 
	
	
(space add robi (rect.class new))
(robi translate 130 50)
(robi setColor yellow)
(space add momo (oval.class new))
(momo setColor red)
(momo translate 80 80)
(space add pif (image.class new alien.gif))
(pif translate 100 0)
(space add hello (label.class new "Hello world"))
(hello translate 10 10)
(hello setColor black)

*/

import java.awt.Dimension;

import graphicLayer.GBounded;
import graphicLayer.GImage;
import graphicLayer.GOval;
import graphicLayer.GRect;
import graphicLayer.GSpace;
import graphicLayer.GString;
import stree.parser.SNode;



public class Exercice4_2_0 {
	// Une seule variable d'instance
	Environment environment = new Environment();

	public Exercice4_2_0() {
		GSpace space = new GSpace("Exercice 4", new Dimension(200, 100));
		space.open();

		Reference spaceRef = new Reference(space);
		Reference rectClassRef = new Reference(GRect.class);
		Reference ovalClassRef = new Reference(GOval.class);
		Reference imageClassRef = new Reference(GImage.class);
		Reference stringClassRef = new Reference(GString.class);
		Reference scriptClassRef = new Reference(null);

		spaceRef.addCommand("setColor", new SetColor());
		spaceRef.addCommand("sleep", new Sleep());
		spaceRef.addCommand("translate", new Translate());
		spaceRef.addCommand("add", new AddElement());
		spaceRef.addCommand("del", new DelElement());
		spaceRef.addCommand("setDim", new Command() {
			public Reference run(Reference ref, SNode methode){
		        try {
		            ((GSpace) ref.receiver).changeWindowSize(new Dimension(Integer.parseInt(methode.get(2).contents()), Integer.parseInt(methode.get(3).contents())));
		        } catch (Exception e) {
		            //TODO: handle exception
		            ((GBounded) ref.receiver).setHeight(Integer.parseInt(methode.get(2).contents()));
		            ((GBounded) ref.receiver).setWidth(Integer.parseInt(methode.get(3).contents()));
		        }

		        return ref;
		    }
		});
		
		rectClassRef.addCommand("new", new NewElement());
		ovalClassRef.addCommand("new", new NewElement());
		imageClassRef.addCommand("new", new NewImage());
		stringClassRef.addCommand("new", new NewString());

		// add children
		rectClassRef.addCommand("addChild", new AddChild());
		ovalClassRef.addCommand("addChild", new AddChild());
		imageClassRef.addCommand("addChild", new AddChild());
		stringClassRef.addCommand("addChild", new AddChild());

		// add element
		rectClassRef.addCommand("add", new AddElement());
		ovalClassRef.addCommand("add", new AddElement());

		environment.addReference("space", spaceRef);
		environment.addReference("Rect", rectClassRef);
		environment.addReference("Oval", ovalClassRef);
		environment.addReference("Image", imageClassRef);
		environment.addReference("Label", stringClassRef);
		environment.addReference("script", scriptClassRef);
		
	}
	
	

	public static void main(String[] args) {
		new Exercice4_2_0();
	}

}