package exercice1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import graphicLayer.GRect;
import graphicLayer.GSpace;

public class Exercice1_0 {
    GSpace space = new GSpace("Exercice 1", new Dimension(200, 150));
    GRect robi = new GRect();

    public Exercice1_0() {
        space.addElement(robi);
        space.open();
        try {
            
            while(true) {
              //R�cup�ration des dimensions de l'espace
                int width = space.getWidth();
                int height = space.getHeight();
                Random rand = new Random();
              //Cr�ation d'une couleur al�atoire
                float r = rand.nextFloat();
                float g = rand.nextFloat();
                float b = rand.nextFloat();
                Color randomColor = new Color(r, g, b);
                
              //Sleep durant une seconde
                TimeUnit.MILLISECONDS.sleep(1000);
              //Cr�ation d'un point en haut � droite
                Point p = new Point(width-robi.getWidth(), 0); 
              //D�placement du robi sur le point cr�e
                robi.translate(p);
              //Changement de la couleur du robi avec une couleur al�atoire
                robi.setColor(randomColor);
                
                rand = new Random();
                randomColor = new Color(rand.nextFloat(), rand.nextFloat(), rand.nextFloat());
              //sleep durant une seconde
                TimeUnit.MILLISECONDS.sleep(1000);
              //point en bas � droite
                p.move(0, height-robi.getHeight());
              //d�placement de robi sur le point
                robi.translate(p);
                robi.setColor(randomColor);
                
                rand = new Random();
                randomColor = new Color(rand.nextFloat(), rand.nextFloat(), rand.nextFloat());
              //sleep durant une seconde
                TimeUnit.MILLISECONDS.sleep(1000);
              //point en bas � gauche
                p.move(-width+robi.getWidth(), 0);
              //d�placement de robi sur le point
                robi.translate(p);
                robi.setColor(randomColor);
                
                rand = new Random();
                randomColor = new Color(rand.nextFloat(), rand.nextFloat(), rand.nextFloat());
              //sleep durant une seconde
                TimeUnit.MILLISECONDS.sleep(1000);
                p.move(0, -height+robi.getHeight());
              //point en haut � gauche
                robi.translate(p);
              //d�placement de robi sur le point
                robi.setColor(randomColor);
                
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Exercice1_0();
    }

}