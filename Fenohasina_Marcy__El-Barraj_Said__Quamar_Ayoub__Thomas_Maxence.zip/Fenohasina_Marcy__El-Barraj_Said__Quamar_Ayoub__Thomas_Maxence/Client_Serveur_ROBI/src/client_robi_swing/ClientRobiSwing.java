package client_robi_swing;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.UIManager;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.ObjectMapper;

import serveur_robi_swing.JSON;

public class ClientRobiSwing {

	private JFrame frame = null;

	private String title = "IHM Robi";

	private Font dialogFont = new Font("Dialog", Font.PLAIN, 12);
	private Font courierFont = new Font("Courier", Font.PLAIN, 12);

	private Button button_file = null;
	private Button button_start = null;
	private Button button_stop = null;

	private JTextPane txt_in = null; // saisie expressions ROBI
	private JScrollPane s_txt_in = null;

	private JTextPane txt_out = null; // affichage des résultats
	private JScrollPane s_txt_out = null;
	
	private String currentDir = ".";
	
	
	private Socket socket;
	OutputStream os = null;
	PrintStream ps = null;
	
	public ClientRobiSwing() {
		frame = new JFrame(title);
		Component contents = createComponents();
		frame.getContentPane().add(contents);
		// frame.setJMenuBar(bar);

		// Finish setting up the frame, and show it.
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});

		frame.pack();
		frame.setSize(800, 600);
		frame.setVisible(true);

	}

	public Component createComponents() {
		JPanel panel = new JPanel();

		// boutons
		JPanel panel_button = new JPanel();
		panel_button.setLayout(new GridLayout(1, 3));

		button_file = new Button("Fichier");
		button_start = new Button("Start");
		button_stop = new Button("Stop");

		button_file.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txt_out.setText(txt_out.getText() + "sélection d'un fichier\n");
				String f = selectionnerFichier();
				txt_out.setText(txt_out.getText() + "fichier sélectionné : "+f+"\n");
				
			}
		});

		button_start.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                txt_out.setText(txt_out.getText() + "clic bouton start\n");

               
                try {
                    socket = new Socket("localhost",8002);
                    os = socket.getOutputStream(); // flot pour transmettre le JSON
        			ps = new PrintStream(os);
        			String type = "";
        			if(txt_in.getText().charAt(1) == 'r') {
        				type = "robi";
        			}
        			else if(txt_in.getText().charAt(1) == 's') {
        				type = "space";
        			}
        			System.out.println(type);
        			Message m1 = new Message(type,txt_in.getText());
                    ps.println(JSON.Java2Json(m1));
                    System.out.println(JSON.Java2Json(m1.getMess()));
        			

                } catch (UnknownHostException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }

            }
        });

		button_stop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txt_out.setText(txt_out.getText() + "clic bouton stop\n");
				try {
					Message m2 = new Message("stop", "stop");
					ps.println(JSON.Java2Json(m2));
					
					os.close();
					ps.close();
					socket.close();
					System.out.print("stop");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});

		panel_button.add(button_file);
		panel_button.add(button_start);
		panel_button.add(button_stop);

		// zones d'affichage ou de saisie
		JPanel panel_edit = new JPanel();
		panel_edit.setLayout(new GridLayout(1, 2));

		txt_in = new JTextPane();
		txt_in.setEditable(true);
		txt_in.setFont(courierFont);
		s_txt_in = new JScrollPane();
		s_txt_in.setPreferredSize(new Dimension(640, 480));
		s_txt_in.getViewport().add(txt_in);

		txt_out = new JTextPane();
		txt_out.setEditable(true);
		txt_out.setFont(courierFont);
		s_txt_out = new JScrollPane();
		s_txt_out.setPreferredSize(new Dimension(640, 480));
		s_txt_out.getViewport().add(txt_out);

		panel_edit.add(s_txt_in);
		panel_edit.add(s_txt_out);

		panel.setLayout(new BorderLayout());
		panel.add(panel_button, BorderLayout.NORTH);
		panel.add(panel_edit, BorderLayout.CENTER);

		return (panel);

	}

	public String selectionnerFichier() {
		JFileChooser chooser = new JFileChooser();
		chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		File fdir = new File(currentDir);
		chooser.setCurrentDirectory(fdir);
		if (chooser.showDialog(frame, "Sélection d'un fichier") == JFileChooser.APPROVE_OPTION) {
			File selected = chooser.getSelectedFile();
			String destination = new String(selected.getParent() + File.separatorChar + selected.getName());
			currentDir = selected.getParent();
			return (destination);
		}
		return ("");
	}

	public static void main(String[] args) {

		try {
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		new ClientRobiSwing();
	}
}
