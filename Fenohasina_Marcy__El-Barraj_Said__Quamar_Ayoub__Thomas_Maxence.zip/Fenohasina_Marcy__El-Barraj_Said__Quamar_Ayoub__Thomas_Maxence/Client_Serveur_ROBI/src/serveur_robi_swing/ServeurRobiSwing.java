package serveur_robi_swing;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.io.Reader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Iterator;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;

import exercice3.Exercice3_0;
import exercice3.Exercice3_interpreter;
import exercice4.Exercice4_2_0;
import tools.Tools;

import graphicLayer.GRect;
import graphicLayer.GSpace;
import stree.parser.SNode;
import stree.parser.SParser;

public class ServeurRobiSwing{
	
	/*static GSpace space = new GSpace("ROBIC", new Dimension(200, 100));
    static GRect robi = new GRect();*/
    
	public static void main(String[] args) throws IOException {
		
		System.out.println("Serveur robi lancé");
		ServerSocket serveur = new ServerSocket(8002);
		while(true) {
			new ClientThread(serveur.accept()).run();
		}
	}
	
	public static class ClientThread implements Runnable{
		private Socket socket;
		
		public ClientThread(Socket socket) {
			this.socket = socket;
		}
			
		@Override
		public void run() {
			try {
				Exercice3_interpreter interpreter = new Exercice3_interpreter();
				interpreter.space.open();
				
				BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream(),"utf-8"));
				PrintStream ps = new PrintStream(socket.getOutputStream());
				
				String s = "";
				
				while((s = br.readLine())!= null) {
					System.out.println("Attente d'un script...");
					Message m = (Message) JSON.Json2Java(s, Message.class);
					if(m.getType().equals("robi")) {
						System.out.println("robi : " + m.getMess());
						interpreter.script = m.getMess();
						interpreter.runScript();
						
					}
					if(m.getType().equals("space")) {
						System.out.println("space : " + m.getMess());
						interpreter.script = m.getMess();
						interpreter.runScript();
					}
					else if(m.getType().equals("stop")&&(m.getMess().equals("stop"))) {
						System.out.println("Arrêt ROBI");
						break;
					}
				}
			} catch(IOException e) {
				e.printStackTrace();
			} finally {
				try {
					socket.close();
				} catch(IOException e) {
					e.printStackTrace();
				}
			}
			
		}
	
	
	}
}