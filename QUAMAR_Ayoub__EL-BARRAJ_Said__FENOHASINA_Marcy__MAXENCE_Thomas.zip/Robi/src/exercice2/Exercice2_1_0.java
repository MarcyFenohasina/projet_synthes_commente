package exercice2;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Point;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import graphicLayer.GRect;
import graphicLayer.GSpace;
import stree.parser.SNode;
import stree.parser.SParser;


public class Exercice2_1_0 {
	GSpace space = new GSpace("Exercice 2_1", new Dimension(200, 100));
	GRect robi = new GRect();
	String script = "(space setColor black) (robi setColor yellow) (space color white)\n"
			+ "(robi color red)\n"
			+ "(robi translate 10 0)\n"
			+ "(space sleep 100)\n"
			+ "(robi translate 0 10)\n"
			+ "(space sleep 100)\n"
			+ "(robi translate -10 0)\n"
			+ "(space sleep 100)\n"
			+ "(robi translate 0 -10)";

	public Exercice2_1_0() {
		space.addElement(robi);
		space.open();
		this.runScript();
	}

	private void runScript() {
		SParser<SNode> parser = new SParser<>();
		List<SNode> rootNodes = null;
		try {
			rootNodes = parser.parse(script);
		} catch (IOException e) {
			e.printStackTrace();
		}
		Iterator<SNode> itor = rootNodes.iterator();
		while (itor.hasNext()) {
			this.run(itor.next());
		}
	}
	
//Fonction qui retourne la couleur � partir de son nom (String)
public static Color getColorByName(String name) {
        try {
            return (Color)Color.class.getField(name.toUpperCase()).get(null);
        } catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
            e.printStackTrace();
            return null;
        }
  }

	private void run(SNode expr) {
		//D�composition de la S-expression .. Etude cas par cas
        switch (expr.get(0).contents()) {
        //Etude cas space : cas Color et Sleep possibles
            case "space":
                switch(expr.get(1).contents()) {
                case "color" :
                	//Appel de getColorByName
                    space.setColor(getColorByName(expr.get(2).contents()));
                    break;
                case "sleep" :
                    int time = Integer.parseInt(expr.get(2).contents());
                    try {
                        TimeUnit.MILLISECONDS.sleep(time);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            //cas Robi : cas Translate et Color possibles
            case "robi":
                switch(expr.get(1).contents()) {
                	//Cr�ation d'un point et d�placement du Robi � ce point
                    case "translate" :
                        Point p = new Point();
                        int x = Integer.parseInt(expr.get(2).contents());
                        int y = Integer.parseInt(expr.get(3).contents());
                        System.out.println(x + y);
                        p.move(x, y);
                        robi.translate(p);
                        break;
                   //Appel de getColorByName
                    case "color" :
                        robi.setColor(getColorByName(expr.get(2).contents()));
                        break;
                    default :
                        break;
                }
            default:
                break;
        }
    }
	
	public static void main(String[] args) {
		new Exercice2_1_0();
	}

}