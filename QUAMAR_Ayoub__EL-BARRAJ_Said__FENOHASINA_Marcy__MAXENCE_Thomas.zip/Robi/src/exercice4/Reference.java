package exercice4;

import java.util.HashMap;
import java.util.Map;
import stree.parser.SNode;
//Classe R�ference qui a pour instance receiver qui est le receveur de commande et la liste 
//de commandes
//La m�thode getCommandeByName et addCommande permettent respectivement de r�cuperer et d'ajouter 
//une commande � la liste
public class Reference {

    Object receiver;
    Map<String, Command> primitives;
    
    public Reference(Object receiver) {
        this.receiver = receiver;
        primitives = new HashMap<String, Command>();
    }

    Command getCommandByName(String selector){
        return primitives.get(selector);
    }

    void addCommand(String selector, Command primitive){
        primitives.put(selector, primitive);
    }

    void run(SNode method){
    	
        this.primitives.get(method.get(1).contents()).run(this, method);
    }

    public Object getReceiver() {
        return receiver;
    }
}
