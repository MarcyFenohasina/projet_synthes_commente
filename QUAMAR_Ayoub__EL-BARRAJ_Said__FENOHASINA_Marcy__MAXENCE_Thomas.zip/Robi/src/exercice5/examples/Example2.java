package exercice5.examples;

public class Example2 {
	
	/* 
	 * Ajoute un script newSquare  � Rect 
	 * newSquare est un constructeur qui prend en argument une largeur et retourne un carre
	 * On ne voit que la fenetre par d�faut, vide
	 * 
	 * Le constructeur de fonctionne pas car je n'ai pas pu faire en sorte d'ajouter un script � une reference de classe
	 * De plus, l'op�rateur return (le ^) n'est pas du tout mis en oeuvre
	 * 
	 * Pour permettre � ce type de script de fonctionner, il faudrait revoir la conception de la fa�on suivante :
	 * bla bla constructeur bla bla
	 * bla bla bla le return (^) pourrait �tre naturellement trait� par l'interpr�teur bla bla 
	 * 
	 */
	String script = "( space add robi (Rect new ) )\n"
			+ "( space.robi addScript addRect (\n"
			+ "( self name w c )\n"
			+ "( self add name ( Rect new ) )\n"
			+ "( self.name setColor c )\n"
			+ "( self.name setDim w w ) ) )\n"
			+ "( space.robi addRect mySquare 30 yellow )";
	
	
	public  void launch() {
		Exercice5 exo = new Exercice5();
		exo.oneShot(script);
	}
	
	public static void main(String[] args) {
		new Example2().launch();
	}
}
  